package br.com.pulso;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.NumberFormat;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/** Interface desktop: componentes Swing comuns, navegação lateral e formulários. */
public final class AcademiaFrame extends JFrame {
    private static final Color NAVY=Visual.DARK, GREEN=Visual.ORANGE, BG=Visual.BG, TEXT=Visual.INK, MUTED=Visual.MUTED, LINE=Visual.LINE;
    private final AcademiaService service;
    private JPanel content;
    private String current="Visão geral";
    private JTable table;
    private List<Map<String,Object>> rows=List.of();
    private final Map<String,JButton> navigation=new LinkedHashMap<>();
    private final NumberFormat currency=NumberFormat.getCurrencyInstance(Locale.forLanguageTag("pt-BR"));
    private record Choice(long id,String name) { @Override public String toString() { return name; } }
    @FunctionalInterface private interface Work { void run() throws Exception; }
    public AcademiaFrame(AcademiaService service) {
        super("Pulso | Academia Movimento"); this.service=service;
        setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(1440,940); setMinimumSize(new Dimension(1200,800)); setLocationRelativeTo(null);
        UIManager.put("Label.font",font(14,false)); UIManager.put("Button.font",font(14,true));
        UIManager.put("TextField.font",font(15,false)); UIManager.put("ComboBox.font",font(14,false));
        UIManager.put("OptionPane.messageFont",font(14,false));
        UIManager.put("Panel.background",BG); UIManager.put("ComboBox.background",Color.WHITE);
        UIManager.put("ComboBox.foreground",TEXT); UIManager.put("ComboBox.selectionBackground",new Color(255,233,221));
        UIManager.put("ComboBox.selectionForeground",TEXT); UIManager.put("ScrollBar.width",10);
        showLogin();
    }
    private static Font font(int size,boolean bold) { return new Font("Segoe UI",bold?Font.BOLD:Font.PLAIN,size); }
    private static JPanel panel(LayoutManager layout,Color bg) { JPanel p=new JPanel(layout); p.setBackground(bg); return p; }
    private static JLabel label(String s,int size,boolean bold,Color color) { JLabel l=new JLabel(s); l.setFont(font(size,bold)); l.setForeground(color); return l; }
    private static void pad(JComponent c,int top,int left,int bottom,int right) { c.setBorder(new EmptyBorder(top,left,bottom,right)); }
    private JButton button(String s,boolean primary,Work action) {
        JButton b=new Visual.SoftButton(s,primary,false); b.setBackground(primary?GREEN:Color.WHITE); pad(b,12,17,12,17);
        if(primary && (s.startsWith("Novo")||s.startsWith("Nova")||s.startsWith("Adicionar")||s.startsWith("Criar"))) {b.setIcon(new Visual.Glyph("mais",Color.WHITE,17));b.setIconTextGap(8);}
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); b.addActionListener(e->perform(action)); return b;
    }
    private void perform(Work action) {
        try { action.run(); } catch(Exception e) {
            String message=e instanceof SQLException ? (((SQLException)e).getSQLState()!=null && ((SQLException)e).getSQLState().equals("23505")?"Este registro já existe. Confira o nome ou login informado.":"Não foi possível salvar. Confira os dados e os vínculos do registro.") : e.getMessage();
            JOptionPane.showMessageDialog(this,message,"Confira os dados",JOptionPane.WARNING_MESSAGE);
        }
    }
    private void showLogin() {
        JPanel root=panel(new GridBagLayout(),Color.WHITE);pad(root,20,20,20,20);
        Visual.PhotoPanel brand=new Visual.PhotoPanel("musculacao",28,.5f,.66,.5);brand.setLayout(new BorderLayout());pad(brand,42,42,42,42);
        JPanel logo=panel(new FlowLayout(FlowLayout.LEFT,12,0),NAVY);logo.setOpaque(false);logo.add(new JLabel(new Visual.Glyph("marca",GREEN,34)));logo.add(label("pulso",39,true,Color.WHITE));brand.add(logo,BorderLayout.NORTH);
        JPanel copy=panel(new GridLayout(0,1,0,10),NAVY);copy.setOpaque(false);
        copy.add(label("ACADEMIA MOVIMENTO",13,true,new Color(255,183,137)));
        copy.add(label("Mais movimento.",45,true,Color.WHITE));
        copy.add(label("Menos complicação.",45,true,Color.WHITE));
        copy.add(label("Sua equipe, seus alunos e sua rotina conectados.",16,false,new Color(230,232,235)));
        brand.add(copy,BorderLayout.SOUTH);
        JPanel right=panel(new GridBagLayout(),Color.WHITE); JPanel login=panel(new GridBagLayout(),Color.WHITE); login.setPreferredSize(new Dimension(385,490));
        GridBagConstraints g=new GridBagConstraints(); g.gridx=0; g.fill=GridBagConstraints.HORIZONTAL; g.weightx=1; g.insets=new Insets(0,0,18,0);
        g.gridy=0;login.add(new JLabel(new Visual.Glyph("marca",GREEN,40)),g);
        g.gridy++;login.add(label("Bem-vindo ao Pulso",32,true,TEXT),g);
        g.gridy++; login.add(label("Entre para cuidar da rotina da academia.",15,false,MUTED),g);
        JTextField user=new JTextField(); JPasswordField pass=new JPasswordField(); styleInput(user); styleInput(pass);
        JPanel u=labeled("Seu usuário",user),pw=labeled("Sua senha",pass);u.setBackground(Color.WHITE);pw.setBackground(Color.WHITE);
        g.gridy++; login.add(u,g); g.gridy++; login.add(pw,g);
        JButton enter=button("Entrar",true,()-> { service.login(user.getText(),new String(pass.getPassword())); pass.setText(""); shell(); });
        g.gridy++; login.add(enter,g);g.gridy++;login.add(label("Precisa de acesso? Fale com o administrador.",12,false,MUTED),g);
        right.add(login);GridBagConstraints col=new GridBagConstraints();col.gridx=0;col.gridy=0;col.fill=GridBagConstraints.BOTH;col.weighty=1;col.weightx=.57;root.add(brand,col);col.gridx=1;col.weightx=.43;root.add(right,col);
        setContentPane(root); getRootPane().setDefaultButton(enter); revalidate(); repaint();
    }
    private void shell() throws Exception {
        JPanel root=panel(new BorderLayout(),BG); JPanel side=panel(new BorderLayout(),NAVY); side.setPreferredSize(new Dimension(230,0)); pad(side,33,17,24,17);
        JPanel top=panel(new BorderLayout(10,17),NAVY);JPanel logotype=panel(new FlowLayout(FlowLayout.LEFT,10,0),NAVY);logotype.add(new JLabel(new Visual.Glyph("marca",GREEN,28)));logotype.add(label("pulso",33,true,Color.WHITE));top.add(logotype,BorderLayout.NORTH);
        top.add(label("ACADEMIA MOVIMENTO",10,true,new Color(139,145,153)),BorderLayout.CENTER);top.add(label("GESTÃO DA ACADEMIA",10,true,new Color(98,106,118)),BorderLayout.SOUTH);pad(top,0,9,28,0); side.add(top,BorderLayout.NORTH);
        JPanel links=panel(new GridLayout(0,1,0,7),NAVY); navigation.clear();
        List<String> pages=new ArrayList<>(List.of("Visão geral","Alunos","Modalidades","Planos","Matrículas","Produtos","Movimentações")); if(service.user().admin()) pages.add("Usuários");
        for(String page:pages) {
            JButton b=new Visual.SoftButton(page,false,true); b.setHorizontalAlignment(SwingConstants.LEFT); b.setFont(font(14,false)); b.setForeground(new Color(180,185,193)); b.setBackground(NAVY); pad(b,13,12,13,10);b.setIcon(new Visual.Glyph(page,new Color(155,161,172),20));b.setIconTextGap(13);
            b.addActionListener(e->perform(()->showPage(page))); navigation.put(page,b); links.add(b);
        }
        JPanel linkWrap=panel(new BorderLayout(),NAVY); linkWrap.add(links,BorderLayout.NORTH); side.add(linkWrap,BorderLayout.CENTER);
        JPanel bottom=panel(new BorderLayout(0,18),NAVY);JPanel account=panel(new BorderLayout(12,0),NAVY);account.add(new Visual.Avatar(initials(service.user().nome()),Color.WHITE,new Color(61,65,74),36),BorderLayout.WEST);JPanel names=panel(new GridLayout(0,1,0,4),NAVY);names.add(label(service.user().nome(),13,true,Color.WHITE));names.add(label(service.user().admin()?"Administrador":"Atendente",11,false,new Color(139,145,153)));account.add(names,BorderLayout.CENTER);bottom.add(account,BorderLayout.NORTH);
        JButton leave=new Visual.SoftButton("Encerrar sessão",false,true);leave.setBackground(NAVY);leave.setForeground(new Color(164,170,180));leave.setHorizontalAlignment(SwingConstants.LEFT);leave.setIcon(new Visual.Glyph("sair",new Color(164,170,180),19));leave.setIconTextGap(12);pad(leave,10,10,10,10);leave.addActionListener(e->{service.logout();showLogin();});bottom.add(leave,BorderLayout.SOUTH);side.add(bottom,BorderLayout.SOUTH);
        JPanel workspace=panel(new BorderLayout(),BG);JPanel bar=panel(new BorderLayout(),Color.WHITE);pad(bar,18,32,18,32);bar.add(label("Academia Movimento  /  Gestão",13,false,MUTED),BorderLayout.WEST);bar.add(label(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM",Locale.forLanguageTag("pt-BR"))),12,false,MUTED),BorderLayout.EAST);workspace.add(bar,BorderLayout.NORTH);
        content=panel(new BorderLayout(0,24),BG); pad(content,26,30,24,30);workspace.add(content,BorderLayout.CENTER);root.add(side,BorderLayout.WEST); root.add(workspace,BorderLayout.CENTER); setContentPane(root); getRootPane().setDefaultButton(null); showPage("Visão geral");
    }
    private static String initials(String name){String[] pieces=name.trim().split("\\s+");return (pieces[0].substring(0,1)+(pieces.length>1?pieces[pieces.length-1].substring(0,1):"")).toUpperCase(Locale.ROOT);}
    private void showPage(String page) throws Exception {
        current=page; content.removeAll(); for(var e:navigation.entrySet()){boolean active=e.getKey().equals(page);e.getValue().setBackground(active?new Color(54,38,32):NAVY);e.getValue().setForeground(active?new Color(255,151,106):new Color(180,185,193));e.getValue().setIcon(new Visual.Glyph(e.getKey(),active?new Color(255,151,106):new Color(155,161,172),20));}
        JPanel heading=panel(new BorderLayout(),BG),titles=panel(new BorderLayout(0,8),BG); titles.add(label(page.equals("Visão geral")?"Seu dia na academia":page,30,true,TEXT),BorderLayout.NORTH);
        Map<String,String> subtitles=Map.of("Visão geral","O que precisa da atenção da equipe hoje.","Alunos","Cadastro e consulta dos alunos da academia.","Modalidades","Atividades oferecidas aos alunos.","Planos","Valores e duração de cada contratação.","Matrículas","Acompanhe contratos, situações e pagamentos.","Produtos","Confira o saldo e os itens que precisam de reposição.","Movimentações","Entradas e saídas com motivo e responsável.","Usuários","Contas e permissões de acesso da equipe.");
        titles.add(label(subtitles.get(page),14,false,MUTED),BorderLayout.SOUTH);heading.add(titles,BorderLayout.CENTER);if(page.equals("Visão geral")){JPanel action=panel(new GridBagLayout(),BG);action.add(button("Nova matrícula",true,()->matriculaForm()));heading.add(action,BorderLayout.EAST);}content.add(heading,BorderLayout.NORTH);
        if(page.equals("Visão geral")) dashboard(); else listing(page); content.revalidate(); content.repaint();
    }
    private void dashboard() throws Exception {
        Database db=service.database(); JPanel body=new Visual.DashboardPanel();JPanel upper=panel(new BorderLayout(0,20),BG);
        Visual.PhotoPanel hero=new Visual.PhotoPanel("musculacao",22,.95f,.5,.15);hero.setLayout(new BorderLayout());hero.setPreferredSize(new Dimension(0,195));pad(hero,25,28,22,28);
        JPanel copy=panel(new GridLayout(0,1,0,7),NAVY);copy.setOpaque(false);copy.add(label("BEM-VINDO À ACADEMIA MOVIMENTO",11,true,new Color(255,175,135)));copy.add(label("Tudo pronto para",30,true,Color.WHITE));copy.add(label("um novo dia de treino.",30,true,Color.WHITE));copy.add(label("Confira o atendimento e o que precisa da sua atenção.",13,false,new Color(219,222,226)));hero.add(copy,BorderLayout.WEST);upper.add(hero,BorderLayout.NORTH);
        JPanel stats=panel(new GridLayout(1,4,16,0),BG);stats.setPreferredSize(new Dimension(0,128));
        stat(stats,"Alunos ativos",db.scalar("SELECT COUNT(*) FROM alunos WHERE ativo=TRUE"),"Cadastros disponíveis");
        stat(stats,"Matrículas ativas",db.scalar("SELECT COUNT(*) FROM matriculas WHERE situacao='ATIVA'"),"Situação do contrato");
        stat(stats,"Pagamentos pendentes",db.scalar("SELECT COUNT(*) FROM matriculas m LEFT JOIN pagamentos p ON p.matricula_id=m.id WHERE p.id IS NULL AND m.situacao<>'CANCELADA'"),"Valor total da contratação");
        stat(stats,"Itens para repor",db.scalar("SELECT COUNT(*) FROM produtos WHERE saldo<=minimo"),"Saldo no mínimo ou abaixo");upper.add(stats,BorderLayout.SOUTH);body.add(upper,BorderLayout.NORTH);
        JPanel detail=new Visual.RoundPanel(new BorderLayout(0,14),Color.WHITE,18,true);pad(detail,20,22,18,22);JPanel alertHeading=panel(new BorderLayout(),Color.WHITE);alertHeading.add(label("Precisa de atenção",19,true,TEXT),BorderLayout.WEST);alertHeading.add(new Visual.Badge("ESTOQUE",new Color(171,92,31),new Color(255,243,226)),BorderLayout.EAST);detail.add(alertHeading,BorderLayout.NORTH);
        var alerts=db.query("SELECT nome AS produto,saldo,minimo AS mínimo,unidade FROM produtos WHERE saldo<=minimo ORDER BY nome");
        JTable t=makeTable(alerts,new String[]{"produto","saldo","mínimo","unidade"},new String[]{"Produto","Saldo","Mínimo","Unidade"}); detail.add(scroll(t),BorderLayout.CENTER);
        JPanel foot=panel(new BorderLayout(),Color.WHITE);foot.add(label(alerts.size()==1?"1 item com saldo baixo":alerts.size()+" itens com saldo baixo",12,false,MUTED),BorderLayout.CENTER);foot.add(button("Ver estoque",false,()->showPage("Produtos")),BorderLayout.EAST);detail.add(foot,BorderLayout.SOUTH);
        JPanel recent=new Visual.RoundPanel(new BorderLayout(0,14),Color.WHITE,18,true);pad(recent,20,22,18,22);recent.add(label("Últimas matrículas",19,true,TEXT),BorderLayout.NORTH);var last=db.query("SELECT a.nome AS aluno,p.nome AS plano,m.situacao FROM matriculas m JOIN alunos a ON a.id=m.aluno_id JOIN planos p ON p.id=m.plano_id ORDER BY m.id DESC LIMIT 5");recent.add(scroll(makeTable(last,new String[]{"aluno","plano","situacao"},new String[]{"Aluno","Plano","Situação"})),BorderLayout.CENTER);JPanel recentFoot=panel(new FlowLayout(FlowLayout.RIGHT,0,0),Color.WHITE);recentFoot.add(button("Consultar matrículas",false,()->showPage("Matrículas")));recent.add(recentFoot,BorderLayout.SOUTH);
        JPanel lower=panel(new GridLayout(1,2,20,0),BG);lower.add(recent);lower.add(detail);body.add(lower,BorderLayout.CENTER);JScrollPane viewport=new JScrollPane(body,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);viewport.setBorder(BorderFactory.createEmptyBorder());viewport.getViewport().setBackground(BG);Visual.styleScroll(viewport);content.add(viewport,BorderLayout.CENTER);
        content.add(label("Pulso  /  Gestão local da academia",11,false,MUTED),BorderLayout.SOUTH);
    }
    private void stat(JPanel parent,String title,long value,String detail) {
        JPanel p=new Visual.RoundPanel(new BorderLayout(0,7),Color.WHITE,16,true);pad(p,17,18,17,18);JPanel top=panel(new BorderLayout(),Color.WHITE);top.add(label(title,12,false,MUTED),BorderLayout.WEST);top.add(new JLabel(new Visual.Glyph(title.startsWith("Alunos")?"Alunos":title.startsWith("Matrículas")?"Matrículas":title.startsWith("Itens")?"Produtos":"Planos",GREEN,19)),BorderLayout.EAST);p.add(top,BorderLayout.NORTH);p.add(label(Long.toString(value),35,true,TEXT),BorderLayout.CENTER);p.add(label(detail,10,false,MUTED),BorderLayout.SOUTH);parent.add(p);
    }
    private void listing(String page) throws Exception {
        String sql; String[] keys,headers;
        switch(page) {
            case "Alunos" -> { sql="SELECT * FROM alunos ORDER BY nome"; keys=new String[]{"id","nome","cpf","telefone","email","ativo"}; headers=new String[]{"Código","Nome","CPF","Telefone","E-mail","Ativo"}; }
            case "Modalidades" -> {sql="SELECT * FROM modalidades ORDER BY nome";keys=new String[]{"id","nome","descricao"};headers=new String[]{"Código","Nome","Descrição"};}
            case "Planos" -> {sql="SELECT p.*,m.nome AS modalidade FROM planos p JOIN modalidades m ON m.id=p.modalidade_id ORDER BY p.nome";keys=new String[]{"id","nome","modalidade","valor","meses"};headers=new String[]{"Código","Plano","Modalidade","Valor total","Meses"};}
            case "Matrículas" -> {sql="SELECT m.*,a.nome AS aluno,p.nome AS plano,CASE WHEN pg.id IS NULL THEN 'PENDENTE' ELSE 'PAGO' END AS pagamento FROM matriculas m JOIN alunos a ON a.id=m.aluno_id JOIN planos p ON p.id=m.plano_id LEFT JOIN pagamentos pg ON pg.matricula_id=m.id ORDER BY m.id DESC";keys=new String[]{"id","aluno","plano","inicio","fim","situacao","pagamento","valor"};headers=new String[]{"Código","Aluno","Plano","Início","Fim","Situação","Pagamento","Valor"};}
            case "Produtos" -> {sql="SELECT *,CASE WHEN saldo<=minimo THEN 'REPOR' ELSE 'OK' END AS alerta FROM produtos ORDER BY nome";keys=new String[]{"id","nome","unidade","preco","saldo","minimo","alerta"};headers=new String[]{"Código","Produto","Unidade","Preço","Saldo","Mínimo","Estoque"};}
            case "Movimentações" -> {sql="SELECT m.*,p.nome AS produto,u.nome AS responsavel FROM movimentacoes m JOIN produtos p ON p.id=m.produto_id JOIN usuarios u ON u.id=m.usuario_id ORDER BY m.id DESC";keys=new String[]{"id","data","produto","tipo","quantidade","motivo","responsavel"};headers=new String[]{"Código","Data","Produto","Tipo","Qtd.","Motivo","Responsável"};}
            case "Usuários" -> {sql="SELECT id,nome,login,perfil,ativo FROM usuarios ORDER BY nome";keys=new String[]{"id","nome","login","perfil","ativo"};headers=new String[]{"Código","Nome","Login","Perfil","Ativo"};}
            default -> throw new IllegalArgumentException("Tela desconhecida.");
        }
        rows=service.database().query(sql); table=makeTable(rows,keys,headers);
        TableRowSorter<TableModel> sorter=new TableRowSorter<>(table.getModel()); table.setRowSorter(sorter);
        JPanel body=panel(new BorderLayout(0,18),BG); JPanel toolbar=panel(new BorderLayout(14,0),BG);
        Visual.Search searchBox=new Visual.Search(); JTextField search=searchBox.field;search.setToolTipText("Buscar por qualquer informação da lista");
        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e){filter();} public void removeUpdate(javax.swing.event.DocumentEvent e){filter();} public void changedUpdate(javax.swing.event.DocumentEvent e){filter();}
            void filter(){sorter.setRowFilter(RowFilter.regexFilter("(?iu)"+java.util.regex.Pattern.quote(search.getText())));}
        });
        JPanel searchWrap=panel(new BorderLayout(),BG);searchWrap.add(searchBox,BorderLayout.CENTER);searchWrap.setPreferredSize(new Dimension(360,48));toolbar.add(searchWrap,BorderLayout.CENTER);
        JPanel actions=panel(new FlowLayout(FlowLayout.RIGHT,8,0),BG);
        if(page.equals("Matrículas")) {
            actions.add(button("Nova matrícula",true,()->matriculaForm()));
            actions.add(button("Situação",false,()->statusForm()));
            actions.add(button("Pagamento",false,()->paymentForm()));
        } else if(page.equals("Movimentações")) actions.add(button("Registrar movimento",true,()->movementForm(null)));
        else {
            boolean editable=page.equals("Alunos") || service.user().admin();
            if(editable) {String create=Map.of("Alunos","Adicionar aluno","Modalidades","Nova modalidade","Planos","Criar plano","Produtos","Novo produto","Usuários","Adicionar usuário").get(page); actions.add(button(create,true,()->editForm(null))); actions.add(button("Editar",false,()->editForm(selected()))); }
            if(page.equals("Produtos")) actions.add(button("Movimentar",true,()->movementForm(selected())));
        }
        toolbar.add(actions,BorderLayout.EAST);body.add(toolbar,BorderLayout.NORTH);
        JPanel records=new Visual.RoundPanel(new BorderLayout(0,14),Color.WHITE,18,true);pad(records,18,20,16,20);JPanel tableHeading=panel(new BorderLayout(),Color.WHITE);tableHeading.add(label(page.equals("Movimentações")?"Registro de entradas e saídas":"Lista de "+page.toLowerCase(Locale.ROOT),17,true,TEXT),BorderLayout.WEST);tableHeading.add(new Visual.Badge(rows.size()==1?"1 registro":rows.size()+" registros",MUTED,new Color(242,244,247)),BorderLayout.EAST);records.add(tableHeading,BorderLayout.NORTH);records.add(scroll(table),BorderLayout.CENTER);
        if(page.equals("Modalidades")) {JPanel center=panel(new BorderLayout(0,20),BG);center.add(modalityGallery(),BorderLayout.NORTH);center.add(records,BorderLayout.CENTER);body.add(center,BorderLayout.CENTER);}else body.add(records,BorderLayout.CENTER);
        JPanel below=panel(new BorderLayout(),BG); below.add(label("Selecione uma linha para consultar ou usar as ações",12,false,MUTED),BorderLayout.WEST);
        if(page.equals("Matrículas")) below.add(button("Histórico",false,()->history()),BorderLayout.EAST);
        if(page.equals("Produtos")) below.add(label("REPOR: saldo menor ou igual ao mínimo",13,true,GREEN),BorderLayout.EAST);
        body.add(below,BorderLayout.SOUTH); content.add(body,BorderLayout.CENTER);
    }
    private JPanel modalityGallery() throws Exception {
        JPanel gallery=panel(new GridLayout(1,3,18,0),BG);gallery.setPreferredSize(new Dimension(0,230));
        String[] labels={"Musculação","Funcional","Pilates"},images={"musculacao","funcional","pilates"};
        for(int i=0;i<labels.length;i++){
            String name=labels[i];var count=service.database().scalar("SELECT COUNT(*) FROM planos p JOIN modalidades m ON p.modalidade_id=m.id WHERE LOWER(m.nome)=LOWER(?)",name);
            Visual.PhotoPanel tile=new Visual.PhotoPanel(images[i],18,.1f,.65,.35);tile.setLayout(new BorderLayout());pad(tile,17,20,17,20);
            JPanel bottom=panel(new BorderLayout(0,7),NAVY);bottom.setOpaque(false);bottom.add(label(name,23,true,Color.WHITE),BorderLayout.NORTH);bottom.add(label(((Number)count).longValue()==1?"1 plano disponível":count+" planos disponíveis",12,false,new Color(225,228,232)),BorderLayout.CENTER);tile.add(bottom,BorderLayout.SOUTH);
            tile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));tile.setToolTipText("Selecionar modalidade "+name);tile.addMouseListener(new java.awt.event.MouseAdapter(){@Override public void mouseClicked(java.awt.event.MouseEvent e){for(int r=0;r<table.getRowCount();r++)if(table.getValueAt(r,1).equals(name)){table.setRowSelectionInterval(r,r);table.scrollRectToVisible(table.getCellRect(r,1,true));return;}}});gallery.add(tile);
        }
        return gallery;
    }
    private JTable makeTable(List<Map<String,Object>> data,String[] keys,String[] headers) {
        DefaultTableModel model=new DefaultTableModel(headers,0) { @Override public boolean isCellEditable(int r,int c){return false;} };
        for(var row:data) {Object[] cells=new Object[keys.length]; for(int i=0;i<keys.length;i++) cells[i]=format(row.get(keys[i])); model.addRow(cells);}
        JTable t=new JTable(model); t.setRowHeight(64); t.setFont(font(13,false)); t.setForeground(TEXT); t.setSelectionBackground(new Color(255,238,227)); t.setSelectionForeground(TEXT); t.setGridColor(LINE);t.setShowGrid(false);t.setIntercellSpacing(new Dimension(0,0));t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); t.setFillsViewportHeight(true); t.setBackground(Color.WHITE);
        t.getTableHeader().setFont(font(11,true));t.getTableHeader().setForeground(MUTED);t.getTableHeader().setBackground(new Color(247,248,250));t.getTableHeader().setPreferredSize(new Dimension(0,42));t.getTableHeader().setReorderingAllowed(false);
        t.getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer(){@Override public Component getTableCellRendererComponent(JTable tb,Object v,boolean selected,boolean focus,int r,int col){super.getTableCellRendererComponent(tb,v,selected,focus,r,col);setText(v.toString().toUpperCase(Locale.ROOT));setFont(font(10,true));setForeground(MUTED);setBackground(new Color(247,248,250));setBorder(new EmptyBorder(8,12,8,12));return this;}});
        TableCellRenderer renderer=new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb,Object v,boolean selected,boolean focus,int r,int c) {
                super.getTableCellRendererComponent(tb,v,selected,focus,r,c);setFont(font(13,false));setBorder(new MatteBorder(0,0,1,0,new Color(242,244,247)));setToolTipText(v==null?null:v.toString());
                Color rowBg=selected?new Color(255,238,227):Color.WHITE;setBackground(rowBg);setForeground(TEXT);String text=v==null?"":v.toString();String header=tb.getColumnName(c);
                Map<String,String> status=Map.ofEntries(Map.entry("ATIVA","Ativa"),Map.entry("TRANCADA","Trancada"),Map.entry("CANCELADA","Cancelada"),Map.entry("PAGO","Pago"),Map.entry("PENDENTE","Pendente"),Map.entry("REPOR","Repor"),Map.entry("OK","Em dia"),Map.entry("ENTRADA","Entrada"),Map.entry("SAIDA","Saída"),Map.entry("ADMIN","Admin"),Map.entry("ATENDENTE","Atendente"));
                if(status.containsKey(text)||header.equals("Ativo")){
                    boolean ok=Set.of("ATIVA","PAGO","OK","ENTRADA","Sim").contains(text),bad=Set.of("CANCELADA","SAIDA","Não").contains(text);
                    Color fg=ok?new Color(47,127,88):bad?new Color(175,74,64):new Color(168,106,30),bg=ok?new Color(233,247,239):bad?new Color(253,237,233):new Color(255,245,226);
                    JPanel wrap=panel(new FlowLayout(FlowLayout.LEFT,12,18),rowBg);wrap.setBorder(new MatteBorder(0,0,1,0,new Color(242,244,247)));wrap.add(new Visual.Badge(status.getOrDefault(text,text),fg,bg));wrap.setToolTipText(text);return wrap;
                }
                if((header.equals("Nome") && (current.equals("Alunos")||current.equals("Usuários")))||header.equals("Aluno")){
                    JPanel wrap=panel(new BorderLayout(11,0),rowBg);wrap.setBorder(new CompoundBorder(new MatteBorder(0,0,1,0,new Color(242,244,247)),new EmptyBorder(10,12,10,8)));wrap.add(new Visual.Avatar(initials(text),new Color(150,84,47),new Color(255,235,219),34),BorderLayout.WEST);wrap.add(label(text,13,true,TEXT),BorderLayout.CENTER);wrap.setToolTipText(text);return wrap;
                }
                setBorder(new CompoundBorder(new MatteBorder(0,0,1,0,new Color(242,244,247)),new EmptyBorder(0,12,0,12)));return this;
            }
        }; t.setDefaultRenderer(Object.class,renderer);
        for(int i=0;i<headers.length;i++){String h=headers[i];t.getColumnModel().getColumn(i).setPreferredWidth(h.equals("Código")?60:h.equals("Aluno")||h.equals("Nome")||h.equals("Produto")?210:h.equals("Motivo")?240:h.equals("Plano")?190:h.equals("E-mail")?210:h.equals("Data")?170:120);}
        return t;
    }
    private String format(Object v) {
        if(v==null)return "";
        if(v instanceof BigDecimal b)return currency.format(b);
        if(v instanceof java.sql.Date d)return d.toLocalDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        if(v instanceof java.sql.Timestamp d)return d.toLocalDateTime().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        if(v instanceof Boolean b)return b?"Sim":"Não";
        if(v instanceof String str && str.matches("[0-9]{11}") && AcademiaService.validCpf(str))return str.substring(0,3)+"."+str.substring(3,6)+"."+str.substring(6,9)+"-"+str.substring(9);
        return v.toString();
    }
    private JScrollPane scroll(JTable t){JScrollPane sc=new JScrollPane(t);sc.setBorder(BorderFactory.createEmptyBorder());sc.getViewport().setBackground(Color.WHITE);Visual.styleScroll(sc);return sc;}
    private Map<String,Object> selected() {
        int row=table.getSelectedRow(); if(row<0)throw new IllegalArgumentException("Selecione um registro na lista.");return rows.get(table.convertRowIndexToModel(row));
    }
    private static void styleInput(JTextField input) {input.setFont(font(15,false));input.setBackground(Color.WHITE);input.setForeground(TEXT);input.setCaretColor(GREEN);input.setPreferredSize(new Dimension(250,48));input.setBorder(new Visual.InputBorder());}
    private static JPanel labeled(String name,JComponent input) {JPanel p=panel(new BorderLayout(0,7),BG);p.add(label(name,13,true,MUTED),BorderLayout.NORTH);p.add(input,BorderLayout.CENTER);return p;}
    private final class Form {
        final JDialog dialog=new JDialog(AcademiaFrame.this,true);
        final JPanel fields=panel(new GridBagLayout(),BG);
        int row=0;
        Form(String title) {
            dialog.setTitle(title); dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            JPanel root=panel(new BorderLayout(0,24),BG);pad(root,30,32,30,32);JPanel heading=panel(new BorderLayout(0,8),BG);heading.add(label(title,27,true,TEXT),BorderLayout.NORTH);heading.add(label("Confira os dados antes de salvar.",13,false,MUTED),BorderLayout.SOUTH);root.add(heading,BorderLayout.NORTH);root.add(fields,BorderLayout.CENTER);dialog.setContentPane(root);
        }
        void add(String name,JComponent component) {
            GridBagConstraints g=new GridBagConstraints();g.gridx=0;g.gridy=row++;g.fill=GridBagConstraints.HORIZONTAL;g.weightx=1;g.insets=new Insets(0,0,14,0);fields.add(labeled(name,component),g);
        }
        JTextField text(String name,Object value) {JTextField t=new JTextField(value==null?"":value.toString());styleInput(t);add(name,t);return t;}
        JComboBox<String> options(String name,String[] choices,String selected) {JComboBox<String> c=new JComboBox<>(choices);Visual.styleCombo(c);if(selected!=null)c.setSelectedItem(selected);add(name,c);return c;}
        JCheckBox check(String name,boolean selected){JCheckBox c=new JCheckBox("Sim",selected);c.setBackground(BG);add(name,c);return c;}
        JComboBox<Choice> choices(String name,String sql,Object selected) throws Exception {
            List<Map<String,Object>> data=service.database().query(sql);JComboBox<Choice> c=new JComboBox<>();
            for(var r:data){String title=r.get("nome").toString();if(r.containsKey("valor"))title+=" ("+format(r.get("valor"))+")";Choice choice=new Choice(AcademiaService.number(r,"id"),title);c.addItem(choice);if(selected instanceof Number n && n.longValue()==choice.id())c.setSelectedItem(choice);}
            Visual.styleCombo(c);add(name,c);return c;
        }
        void show(Work save) {
            JPanel actions=panel(new FlowLayout(FlowLayout.RIGHT,8,0),BG);actions.add(button("Cancelar",false,()->dialog.dispose()));
            JButton submit=button("Salvar",true,()->{save.run();dialog.dispose();showPage(current);});actions.add(submit);dialog.getContentPane().add(actions,BorderLayout.SOUTH);dialog.getRootPane().setDefaultButton(submit);
            dialog.pack();dialog.setSize(Math.max(540,dialog.getWidth()),dialog.getHeight());dialog.setLocationRelativeTo(AcademiaFrame.this);dialog.setVisible(true);
        }
    }
    private Object val(Map<String,Object> row,String key) {return row==null?null:row.get(key);}
    private static long chosen(JComboBox<Choice> c) {Choice v=(Choice)c.getSelectedItem();if(v==null)throw new IllegalArgumentException("Cadastre os dados necessários antes de continuar.");return v.id();}
    private static BigDecimal decimal(JTextField t) {try{return new BigDecimal(t.getText().trim().replace(",","."));}catch(Exception e){throw new IllegalArgumentException("Informe o valor em reais, por exemplo: 129,90.");}}
    private static int integer(JTextField t) {try{return Integer.parseInt(t.getText().trim());}catch(Exception e){throw new IllegalArgumentException("Informe uma quantidade inteira válida.");}}
    private void editForm(Map<String,Object> r) throws Exception {
        Long id=r==null?null:AcademiaService.number(r,"id");String entity=Map.of("Alunos","aluno","Modalidades","modalidade","Planos","plano","Produtos","produto","Usuários","usuário").get(current);Form f=new Form((id==null?"Cadastrar ":"Editar ")+entity);
        JTextField nome=f.text("Nome",val(r,"nome"));
        switch(current) {
            case "Alunos" -> {
                JTextField cpf=f.text("CPF",val(r,"cpf")),telefone=f.text("Telefone com DDD",val(r,"telefone")),email=f.text("E-mail",val(r,"email"));JCheckBox ativo=f.check("Aluno ativo",r==null||Boolean.TRUE.equals(val(r,"ativo")));
                f.show(()->service.saveAluno(id,nome.getText(),cpf.getText(),telefone.getText(),email.getText(),ativo.isSelected()));
            }
            case "Modalidades" -> {JTextField descricao=f.text("Descrição",val(r,"descricao"));f.show(()->service.saveModalidade(id,nome.getText(),descricao.getText()));}
            case "Planos" -> {
                JComboBox<Choice> m=f.choices("Modalidade","SELECT id,nome FROM modalidades ORDER BY nome",val(r,"modalidade_id"));JTextField valor=f.text("Valor total do plano (R$)",val(r,"valor")),meses=f.text("Duração em meses",r==null?1:val(r,"meses"));
                f.show(()->service.savePlano(id,nome.getText(),chosen(m),decimal(valor),integer(meses)));
            }
            case "Produtos" -> {
                JTextField unidade=f.text("Unidade de medida",r==null?"unidade":val(r,"unidade")),preco=f.text("Preço unitário (R$)",val(r,"preco")),minimo=f.text("Estoque mínimo",r==null?0:val(r,"minimo"));f.add("Saldo inicial",label("Registre uma entrada após salvar o produto.",13,false,MUTED));
                f.show(()->service.saveProduto(id,nome.getText(),unidade.getText(),decimal(preco),integer(minimo)));
            }
            case "Usuários" -> {
                JTextField login=f.text("Login",val(r,"login"));JPasswordField senha=new JPasswordField();styleInput(senha);f.add(id==null?"Senha (mínimo de 8 caracteres)":"Nova senha (em branco mantém a atual)",senha);
                JComboBox<String> perfil=f.options("Perfil",new String[]{"ATENDENTE","ADMIN"},r==null?"ATENDENTE":val(r,"perfil").toString());JCheckBox ativo=f.check("Conta ativa",r==null||Boolean.TRUE.equals(val(r,"ativo")));
                f.show(()->service.saveUsuario(id,nome.getText(),login.getText(),new String(senha.getPassword()),perfil.getSelectedItem().toString(),ativo.isSelected()));
            }
        }
    }
    private void matriculaForm() throws Exception {
        Form f=new Form("Nova matrícula");JComboBox<Choice> aluno=f.choices("Aluno ativo","SELECT id,nome FROM alunos WHERE ativo=TRUE ORDER BY nome",null);
        JComboBox<Choice> plano=f.choices("Plano","SELECT id,nome,valor FROM planos ORDER BY nome",null);
        JTextField inicio=f.text("Início (dd/mm/aaaa)",LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
        f.add("Contratação",label("O pagamento corresponde ao valor total do plano.",13,false,MUTED));
        f.show(()-> {LocalDate data;try{data=LocalDate.parse(inicio.getText(),DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(java.time.format.ResolverStyle.STRICT));}catch(Exception e){throw new IllegalArgumentException("Informe uma data válida no formato dd/mm/aaaa.");} service.matricular(chosen(aluno),chosen(plano),data);});
    }
    private void statusForm() {
        var r=selected();Form f=new Form("Situação da matrícula #"+r.get("id"));JComboBox<String> status=f.options("Nova situação",new String[]{"ATIVA","TRANCADA","CANCELADA"},r.get("situacao").toString());JTextField motivo=f.text("Motivo da alteração",null);
        f.show(()->service.situacao(AcademiaService.number(r,"id"),status.getSelectedItem().toString(),motivo.getText()));
    }
    private void paymentForm() {
        var r=selected();Form f=new Form("Registrar pagamento");f.add("Aluno",label(r.get("aluno").toString(),16,true,TEXT));f.add("Valor da contratação",label(format(r.get("valor")),24,true,GREEN));JComboBox<String> forma=f.options("Forma de pagamento",new String[]{"PIX","DINHEIRO","CARTAO"},"PIX");
        f.show(()->service.pagar(AcademiaService.number(r,"id"),forma.getSelectedItem().toString()));
    }
    private void movementForm(Map<String,Object> r) throws Exception {
        Form f=new Form("Registrar movimentação");JComboBox<Choice> produto=f.choices("Produto e saldo atual","SELECT id,CONCAT(nome,' (saldo: ',saldo,')') AS nome FROM produtos ORDER BY nome",val(r,"id"));
        JComboBox<String> tipo=f.options("Tipo",new String[]{"ENTRADA","SAIDA"},"ENTRADA");JTextField qtd=f.text("Quantidade inteira",1),motivo=f.text("Motivo",null);
        f.show(()->service.movimentar(chosen(produto),tipo.getSelectedItem().toString(),integer(qtd),motivo.getText()));
    }
    private void history() throws Exception {
        var r=selected();long id=AcademiaService.number(r,"id");var hist=service.database().query("SELECT h.data,h.situacao,h.motivo,u.nome AS responsavel FROM historico_matriculas h JOIN usuarios u ON u.id=h.usuario_id WHERE h.matricula_id=? ORDER BY h.id",id);
        JDialog d=new JDialog(this,"Histórico da matrícula #"+id,true);JPanel p=panel(new BorderLayout(0,14),BG);pad(p,22,22,22,22);p.add(label("Alterações de situação",24,true,TEXT),BorderLayout.NORTH);p.add(scroll(makeTable(hist,new String[]{"data","situacao","motivo","responsavel"},new String[]{"Data","Situação","Motivo","Responsável"})),BorderLayout.CENTER);d.setContentPane(p);d.setSize(900,430);d.setLocationRelativeTo(this);d.setVisible(true);
    }
    /** Exporta a mesma interface do aplicativo com dados descartáveis de demonstração. */
    public void captureScreens() throws Exception {
        Files.createDirectories(Path.of("assets/telas")); setVisible(true); capture("01-login");
        service.login("admin","Admin@123");shell();
        String[] pages={"Visão geral","Alunos","Modalidades","Planos","Matrículas","Produtos","Movimentações","Usuários"};
        for(int i=0;i<pages.length;i++){showPage(pages[i]);capture(String.format("%02d-",i+2)+new String[]{"inicio","alunos","modalidades","planos","matriculas","produtos","movimentacoes","usuarios"}[i]);}
    }
    private void capture(String name) throws Exception {
        validate();getContentPane().doLayout();validate();Toolkit.getDefaultToolkit().sync();
        BufferedImage img=new BufferedImage(getContentPane().getWidth(),getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=img.createGraphics();getContentPane().printAll(g);g.dispose();ImageIO.write(img,"png",Path.of("assets/telas/"+name+".png").toFile());
    }
}
