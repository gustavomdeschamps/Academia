package br.com.pulso;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Componentes visuais leves. Todos continuam sendo controles Swing acessíveis. */
final class Visual {
    static final Color DARK=new Color(25,27,30), ORANGE=new Color(232,91,42), INK=new Color(35,39,43), MUTED=new Color(120,126,133), BG=new Color(246,247,249), LINE=new Color(230,233,237);
    private static final Map<String,BufferedImage> IMAGES=new HashMap<>();
    static Font font(int size,boolean bold){return new Font("Segoe UI",bold?Font.BOLD:Font.PLAIN,size);}
    static Graphics2D quality(Graphics g){Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);x.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);return x;}
    static void styleCombo(JComboBox<?> combo){
        combo.setFont(font(14,false));combo.setBackground(Color.WHITE);combo.setForeground(INK);combo.setBorder(new InputBorder());combo.setPreferredSize(new Dimension(300,48));
        combo.setUI(new BasicComboBoxUI(){
            @Override protected JButton createArrowButton(){return new JButton(){
                {setBorder(BorderFactory.createEmptyBorder());setOpaque(false);setContentAreaFilled(false);setFocusable(false);}
                @Override protected void paintComponent(Graphics graphics){Graphics2D g=quality(graphics);g.setColor(MUTED);g.setStroke(new BasicStroke(1.6f));int x=getWidth()/2,y=getHeight()/2;g.drawLine(x-4,y-2,x,y+2);g.drawLine(x,y+2,x+4,y-2);g.dispose();}
            };}
        });
        combo.setRenderer(new DefaultListCellRenderer(){
            @Override public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean selected,boolean focus){super.getListCellRendererComponent(list,value,index,selected,focus);setFont(font(14,false));setBorder(BorderFactory.createEmptyBorder(4,7,4,7));setBackground(selected?new Color(255,238,227):Color.WHITE);setForeground(INK);if(value instanceof String key)setText(switch(key){case "ATIVA"->"Ativa";case "TRANCADA"->"Trancada";case "CANCELADA"->"Cancelada";case "ADMIN"->"Administrador";case "ATENDENTE"->"Atendente";case "ENTRADA"->"Entrada";case "SAIDA"->"Saída";case "DINHEIRO"->"Dinheiro";case "CARTAO"->"Cartão";default->key;});return this;}
        });
    }
    static void styleScroll(JScrollPane pane){
        for(JScrollBar bar:new JScrollBar[]{pane.getVerticalScrollBar(),pane.getHorizontalScrollBar()}){
            bar.setPreferredSize(new Dimension(10,10));bar.setUI(new BasicScrollBarUI(){
                @Override protected JButton createDecreaseButton(int orientation){return empty();}
                @Override protected JButton createIncreaseButton(int orientation){return empty();}
                private JButton empty(){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));b.setMinimumSize(new Dimension(0,0));b.setMaximumSize(new Dimension(0,0));return b;}
                @Override protected void paintTrack(Graphics graphics,JComponent c,Rectangle r){graphics.setColor(Color.WHITE);graphics.fillRect(r.x,r.y,r.width,r.height);}
                @Override protected void paintThumb(Graphics graphics,JComponent c,Rectangle r){if(r.isEmpty()||!scrollbar.isEnabled())return;Graphics2D g=quality(graphics);g.setColor(new Color(210,215,220));g.fillRoundRect(r.x+2,r.y+2,Math.max(4,r.width-4),Math.max(4,r.height-4),6,6);g.dispose();}
            });
        }
    }
    static final class RoundPanel extends JPanel {
        final int radius; final boolean outlined;
        RoundPanel(LayoutManager layout,Color color,int radius,boolean outlined){super(layout);this.radius=radius;this.outlined=outlined;setBackground(color);setOpaque(false);}
        @Override protected void paintComponent(Graphics graphics){Graphics2D g=quality(graphics);g.setColor(getBackground());g.fillRoundRect(0,0,getWidth()-1,getHeight()-1,radius,radius);if(outlined){g.setColor(LINE);g.drawRoundRect(0,0,getWidth()-1,getHeight()-1,radius,radius);}g.dispose();super.paintComponent(graphics);}
    }
    static final class DashboardPanel extends JPanel implements Scrollable {
        DashboardPanel(){super(new BorderLayout(0,22));setBackground(BG);setPreferredSize(new Dimension(0,590));}
        public Dimension getPreferredScrollableViewportSize(){return getPreferredSize();}
        public int getScrollableUnitIncrement(Rectangle visible,int orientation,int direction){return 24;}
        public int getScrollableBlockIncrement(Rectangle visible,int orientation,int direction){return Math.max(24,visible.height-24);}
        public boolean getScrollableTracksViewportWidth(){return true;}
        public boolean getScrollableTracksViewportHeight(){return getParent()!=null && getParent().getHeight()>=getPreferredSize().height;}
    }
    static final class PhotoPanel extends JPanel {
        private final BufferedImage image; private final int radius; private final float shade; private final double focalX,focalY;
        PhotoPanel(String asset,int radius,float shade,double focalX,double focalY){
            this.radius=radius;this.shade=shade;this.focalX=focalX;this.focalY=focalY;setOpaque(false);
            BufferedImage loaded=IMAGES.get(asset);
            if(loaded==null)try{loaded=ImageIO.read(Path.of("assets/imagens",asset+".png").toFile());IMAGES.put(asset,loaded);}catch(Exception ignored){}
            image=loaded;
        }
        @Override protected void paintComponent(Graphics graphics){
            Graphics2D g=quality(graphics);g.clip(new RoundRectangle2D.Double(0,0,getWidth(),getHeight(),radius,radius));
            g.setColor(DARK);g.fillRect(0,0,getWidth(),getHeight());
            if(image!=null){double scale=Math.max((double)getWidth()/image.getWidth(),(double)getHeight()/image.getHeight());int w=(int)Math.ceil(image.getWidth()*scale),h=(int)Math.ceil(image.getHeight()*scale);int x=(int)(-(w-getWidth())*focalX),y=(int)(-(h-getHeight())*focalY);g.drawImage(image,x,y,w,h,null);}
            if(shade>0){g.setPaint(new GradientPaint(0,0,new Color(15,17,20,(int)(255*shade)),getWidth(),0,new Color(15,17,20,15)));g.fillRect(0,0,getWidth(),getHeight());}
            g.setPaint(new GradientPaint(0,getHeight()/2f,new Color(15,17,20,0),0,getHeight(),new Color(15,17,20,160)));g.fillRect(0,0,getWidth(),getHeight());g.dispose();super.paintComponent(graphics);
        }
    }
    static final class SoftButton extends JButton {
        private final boolean primary; private final boolean nav;
        SoftButton(String title,boolean primary,boolean nav){super(title);this.primary=primary;this.nav=nav;setOpaque(false);setContentAreaFilled(false);setBorderPainted(false);setFocusPainted(false);setFont(font(14,true));setForeground(primary?Color.WHITE:INK);setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));setRolloverEnabled(true);}
        @Override protected void paintComponent(Graphics graphics){
            Graphics2D g=quality(graphics);Color bg=getBackground();
            if(!nav){bg=primary?(getModel().isRollover()?ORANGE.brighter():ORANGE):(getModel().isRollover()?new Color(241,243,246):Color.WHITE);}
            else if(getModel().isRollover() && bg.equals(DARK))bg=new Color(40,43,48);
            g.setColor(bg);g.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
            if(!primary && !nav){g.setColor(LINE);g.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);}
            if(hasFocus()){g.setColor(primary?new Color(255,189,149):ORANGE);g.drawRoundRect(2,2,getWidth()-5,getHeight()-5,10,10);}g.dispose();super.paintComponent(graphics);
        }
    }
    static final class InputBorder extends AbstractBorder {
        @Override public Insets getBorderInsets(Component c){return new Insets(12,14,12,14);}
        @Override public Insets getBorderInsets(Component c,Insets i){i.top=12;i.left=14;i.bottom=12;i.right=14;return i;}
        @Override public void paintBorder(Component c,Graphics graphics,int x,int y,int width,int height){Graphics2D g=quality(graphics);g.setColor(c.hasFocus()?ORANGE:LINE);g.drawRoundRect(x,y,width-1,height-1,10,10);g.dispose();}
    }
    static final class Glyph implements Icon {
        final String name; final Color color;final int size;
        Glyph(String name,Color color,int size){this.name=name;this.color=color;this.size=size;}
        public int getIconWidth(){return size;}public int getIconHeight(){return size;}
        public void paintIcon(Component c,Graphics graphics,int x,int y){Graphics2D g=quality(graphics);g.translate(x,y);g.scale(size/24.0,size/24.0);g.setColor(color);g.setStroke(new BasicStroke(1.65f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            switch(name){
                case "Visão geral" -> {for(int a=0;a<2;a++)for(int b=0;b<2;b++)g.drawRoundRect(3+a*11,3+b*11,7,7,2,2);}
                case "Alunos","Usuários" -> {g.drawOval(8,3,8,8);g.draw(new Arc2D.Double(3,12,18,15,0,180,Arc2D.OPEN));}
                case "Modalidades" -> {g.drawLine(3,12,21,12);g.drawRoundRect(5,6,3,12,1,1);g.drawRoundRect(16,6,3,12,1,1);g.drawLine(3,9,3,15);g.drawLine(21,9,21,15);}
                case "Planos" -> {g.drawRoundRect(4,4,16,17,3,3);g.drawLine(8,9,16,9);g.drawLine(8,13,16,13);g.drawLine(8,17,13,17);}
                case "Matrículas" -> {g.drawRoundRect(3,5,18,16,2,2);g.drawLine(7,3,7,7);g.drawLine(17,3,17,7);g.drawLine(3,10,21,10);g.drawLine(8,15,11,18);g.drawLine(11,18,17,13);}
                case "Produtos" -> {g.drawRect(4,7,16,14);g.drawLine(4,7,12,3);g.drawLine(12,3,20,7);g.drawLine(4,7,12,11);g.drawLine(12,11,20,7);g.drawLine(12,11,12,21);}
                case "Movimentações" -> {g.drawLine(3,8,20,8);g.drawLine(16,4,20,8);g.drawLine(20,8,16,12);g.drawLine(21,17,4,17);g.drawLine(8,13,4,17);g.drawLine(4,17,8,21);}
                case "buscar" -> {g.drawOval(3,3,12,12);g.drawLine(13,13,21,21);}
                case "mais" -> {g.drawLine(12,4,12,20);g.drawLine(4,12,20,12);}
                case "sair" -> {g.drawLine(10,4,4,4);g.drawLine(4,4,4,20);g.drawLine(4,20,10,20);g.drawLine(10,12,21,12);g.drawLine(17,8,21,12);g.drawLine(21,12,17,16);}
                case "marca" -> {Path2D line=new Path2D.Double();line.moveTo(1,14);line.lineTo(6,14);line.lineTo(10,4);line.lineTo(14,21);line.lineTo(18,10);line.lineTo(22,10);g.setStroke(new BasicStroke(2.8f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));g.draw(line);}
                default -> {g.drawOval(3,3,18,18);g.drawLine(12,7,12,13);g.fillOval(11,16,2,2);}
            }g.dispose();
        }
    }
    static final class Badge extends JLabel {
        final Color bg;
        Badge(String text,Color fg,Color bg){super(text);this.bg=bg;setFont(font(11,true));setForeground(fg);setBorder(BorderFactory.createEmptyBorder(6,10,6,10));setOpaque(false);}
        @Override protected void paintComponent(Graphics graphics){Graphics2D g=quality(graphics);g.setColor(bg);g.fillRoundRect(0,0,getWidth(),getHeight(),12,12);g.dispose();super.paintComponent(graphics);}
    }
    static final class Avatar extends JLabel {
        final Color bg;
        Avatar(String initials,Color fg,Color bg,int size){super(initials,SwingConstants.CENTER);this.bg=bg;setForeground(fg);setFont(font(size/3,true));setPreferredSize(new Dimension(size,size));}
        @Override protected void paintComponent(Graphics graphics){Graphics2D g=quality(graphics);g.setColor(bg);g.fillOval(0,0,getWidth()-1,getHeight()-1);g.dispose();super.paintComponent(graphics);}
    }
    static final class Search extends JPanel {
        final JTextField field=new JTextField(){
            @Override protected void paintComponent(Graphics graphics){super.paintComponent(graphics);if(getText().isEmpty()&&!hasFocus()){Graphics2D g=quality(graphics);g.setColor(MUTED);g.setFont(getFont());FontMetrics fm=g.getFontMetrics();g.drawString("Buscar nos registros...",0,(getHeight()-fm.getHeight())/2+fm.getAscent());g.dispose();}}
        };
        Search(){super(new BorderLayout(10,0));setBackground(Color.WHITE);setBorder(new InputBorder());JLabel icon=new JLabel(new Glyph("buscar",MUTED,18));add(icon,BorderLayout.WEST);field.setBorder(BorderFactory.createEmptyBorder());field.setFont(font(14,false));field.setBackground(Color.WHITE);add(field,BorderLayout.CENTER);setPreferredSize(new Dimension(300,48));}
    }
}
