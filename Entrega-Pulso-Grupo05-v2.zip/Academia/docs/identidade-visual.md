# Identidade visual

Nome do sistema: **Pulso**. Cliente fictício: **Academia Movimento**.

A marca combina o nome em letras minúsculas com um traço de pulso em laranja. A aplicação usa fundo claro, menu em grafite e fotografias de treino. Os arquivos vetoriais estão em `assets/logomarca.svg` e `assets/logomarca-clara.svg`.

| Cor | Código | Uso |
| --- | --- | --- |
| Grafite | #191B1E | Menu e capa |
| Laranja | #E85B2A | Ações principais e símbolo da marca |
| Cinza claro | #F6F7F9 | Fundo das telas e dos slides |
| Texto escuro | #23272B | Títulos e conteúdo |
| Cinza | #787E85 | Textos de apoio |

Tipografia: Segoe UI na aplicação e Calibri nos slides. Campos e botões têm cantos arredondados. Os indicadores de situação combinam palavras e cores. As fotografias ocupam o login, o início e a galeria de modalidades. As demais telas priorizam os registros e as ações do atendimento.

As três fotografias foram geradas para este projeto. Pessoas e ambientes são fictícios. Os prompts e os arquivos constam em `docs/imagens-ficticias.md`. As imagens ficam na própria pasta do projeto e não dependem de conexão com a internet.

A apresentação usa capturas reais da interface renovada. Os textos e as tabelas dos slides permanecem editáveis.
