# Resultados dos testes

Execução: 2026-10-09T08:47:53.028961900-03:00[America/Sao_Paulo]

43 verificações passaram. Banco isolado H2. Testes de serviço e integração JDBC; a inspeção visual das telas é complementar.

| Caso | Verificação | Resultado |
| --- | --- | --- |
| CT-01 | Operação sem autenticação bloqueada | Passou |
| CT-02 | Login com senha incorreta bloqueado | Passou |
| CT-03 | Entrada SQL no login não autentica | Passou |
| CT-04 | Login válido reconhece administrador | Passou |
| CT-05 | Senha armazenada como hash com salt | Passou |
| CT-06 | Senhas iguais recebem salts diferentes | Passou |
| CT-07 | Cadastro grava e permite consultar aluno | Passou |
| CT-08 | CPF duplicado bloqueado | Passou |
| CT-09 | CPF com dígitos inválidos bloqueado | Passou |
| CT-10 | Nome vazio bloqueado | Passou |
| CT-11 | E-mail inválido bloqueado | Passou |
| CT-12 | Edição atualiza o aluno | Passou |
| CT-13 | Plano relaciona modalidade por chave estrangeira | Passou |
| CT-14 | Plano com preço negativo bloqueado | Passou |
| CT-15 | Plano sem duração válida bloqueado | Passou |
| CT-16 | Matrícula grava validade conforme duração | Passou |
| CT-17 | Matrícula registra histórico inicial | Passou |
| CT-18 | Matrícula aberta duplicada bloqueada | Passou |
| CT-19 | Alteração do plano preserva valor contratado | Passou |
| CT-20 | Aluno com matrícula aberta não pode ser inativado | Passou |
| CT-21 | Trancamento registra situação e histórico | Passou |
| CT-22 | Situação sem motivo bloqueada | Passou |
| CT-23 | Pagamento registra valor contratado e responsável | Passou |
| CT-24 | Pagamento duplicado bloqueado | Passou |
| CT-25 | Matrícula cancelada não pode ser reativada | Passou |
| CT-26 | Nova matrícula permitida após cancelamento | Passou |
| CT-27 | Matrícula para aluno inativo bloqueada | Passou |
| CT-28 | Produto inicia sem saldo | Passou |
| CT-29 | Entrada e saída atualizam saldo | Passou |
| CT-30 | Saldo no mínimo aparece no alerta | Passou |
| CT-31 | Saída maior que saldo bloqueada | Passou |
| CT-32 | Saída rejeitada preserva saldo e histórico | Passou |
| CT-33 | Quantidade zero bloqueada | Passou |
| CT-34 | Movimento sem motivo bloqueado | Passou |
| CT-35 | Atendente não cadastra usuários | Passou |
| CT-36 | Atendente não altera planos | Passou |
| CT-37 | Atendente registra movimento com responsável | Passou |
| CT-38 | Administrador não pode desativar a própria conta | Passou |
| CT-39 | Usuário cadastrado consegue autenticar | Passou |
| CT-40 | Logout encerra a sessão | Passou |
| CT-41 | Saídas simultâneas não deixam saldo negativo | Passou |
| CT-42 | Falha ao gravar histórico desfaz alteração de saldo | Passou |
| CT-43 | Dados persistem após nova abertura do banco | Passou |
