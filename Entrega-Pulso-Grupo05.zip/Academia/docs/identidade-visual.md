# Identidade visual

Nome do sistema: **Pulso**. Cliente fictício: **Academia Movimento**.

A marca usa o nome em letras minúsculas, com ponto final. A ideia é aproximar o sistema da rotina de uma academia sem usar desenhos de halteres ou figuras de atletas. O arquivo vetorial está em `assets/logomarca.svg`.

| Cor | Código | Uso |
| --- | --- | --- |
| Azul escuro | #13242D | Navegação e capa |
| Verde | #277B66 | Ações principais e títulos de apoio |
| Verde claro | #7DDCB3 | Marca sobre fundo escuro |
| Cinza claro | #F4F6F5 | Fundo das telas e dos slides |
| Texto escuro | #192D35 | Conteúdo principal |

Tipografia: Segoe UI na aplicação e Calibri nos slides, ambas disponíveis nesta máquina. A apresentação usa texto curto e capturas reais do sistema. Os slides permanecem editáveis.
