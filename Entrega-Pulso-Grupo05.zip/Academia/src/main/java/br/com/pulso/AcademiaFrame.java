package br.com.pulso;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.NumberFormat;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/** Interface desktop: componentes Swing comuns, navegação lateral e formulários. */
public final class AcademiaFrame extends JFrame {
    private static final Color NAVY=new Color(19,36,45), GREEN=new Color(39,123,102), BG=new Color(244,246,245), TEXT=new Color(25,45,53), MUTED=new Color(101,117,122), LINE=new Color(221,228,225);
    private final AcademiaService service;
    private JPanel content;
    private String current="Visão geral";
    private JTable table;
    private List<Map<String,Object>> rows=List.of();
    private final Map<String,JButton> navigation=new LinkedHashMap<>();
    private final NumberFormat currency=NumberFormat.getCurrencyInstance(Locale.forLanguageTag("pt-BR"));
    private record Choice(long id,String name) { @Override public String toString() { return name; } }
    @FunctionalInterface private interface Work { void run() throws Exception; }
    public AcademiaFrame(AcademiaService service) {
        super("Pulso | Academia Movimento"); this.service=service;
        setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(1240,800); setMinimumSize(new Dimension(1060,690)); setLocationRelativeTo(null);
        UIManager.put("Label.font",font(14,false)); UIManager.put("Button.font",font(14,true));
        UIManager.put("TextField.font",font(15,false)); UIManager.put("ComboBox.font",font(14,false));
        UIManager.put("OptionPane.messageFont",font(14,false));
        showLogin();
    }
    private static Font font(int size,boolean bold) { return new Font("Segoe UI",bold?Font.BOLD:Font.PLAIN,size); }
    private static JPanel panel(LayoutManager layout,Color bg) { JPanel p=new JPanel(layout); p.setBackground(bg); return p; }
    private static JLabel label(String s,int size,boolean bold,Color color) { JLabel l=new JLabel(s); l.setFont(font(size,bold)); l.setForeground(color); return l; }
    private static void pad(JComponent c,int top,int left,int bottom,int right) { c.setBorder(new EmptyBorder(top,left,bottom,right)); }
    private JButton button(String s,boolean primary,Work action) {
        JButton b=new JButton(s); b.setFont(font(14,true)); b.setBackground(primary?GREEN:Color.WHITE); b.setForeground(primary?Color.WHITE:TEXT);
        b.setFocusPainted(false); b.setBorder(new CompoundBorder(new LineBorder(primary?GREEN:LINE),new EmptyBorder(11,16,11,16)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); b.addActionListener(e->perform(action)); return b;
    }
    private void perform(Work action) {
        try { action.run(); } catch(Exception e) {
            String message=e instanceof SQLException ? (((SQLException)e).getSQLState()!=null && ((SQLException)e).getSQLState().equals("23505")?"Este registro já existe. Confira o nome ou login informado.":"Não foi possível salvar. Confira os dados e os vínculos do registro.") : e.getMessage();
            JOptionPane.showMessageDialog(this,message,"Confira os dados",JOptionPane.WARNING_MESSAGE);
        }
    }
    private void showLogin() {
        JPanel root=panel(new GridLayout(1,2),BG);
        JPanel brand=panel(new BorderLayout(),NAVY); pad(brand,55,58,55,58);
        brand.add(label("pulso.",66,true,new Color(125,220,179)),BorderLayout.NORTH);
        JPanel copy=panel(new GridLayout(0,1,0,16),NAVY);
        copy.add(label("Academia Movimento",29,true,Color.WHITE));
        copy.add(label("A rotina da academia",26,false,Color.WHITE));
        copy.add(label("em um só lugar.",26,false,Color.WHITE));
        JPanel wrap=panel(new GridBagLayout(),NAVY); wrap.add(copy); brand.add(wrap,BorderLayout.CENTER);
        brand.add(label("Alunos, matrículas e estoque",16,false,new Color(172,191,191)),BorderLayout.SOUTH);
        JPanel right=panel(new GridBagLayout(),BG); JPanel login=panel(new GridBagLayout(),BG); login.setPreferredSize(new Dimension(380,370));
        GridBagConstraints g=new GridBagConstraints(); g.gridx=0; g.fill=GridBagConstraints.HORIZONTAL; g.weightx=1; g.insets=new Insets(0,0,18,0);
        g.gridy=0; login.add(label("Acesso ao sistema",30,true,TEXT),g);
        g.gridy++; login.add(label("Use sua conta para continuar.",16,false,MUTED),g);
        JTextField user=new JTextField(); JPasswordField pass=new JPasswordField(); styleInput(user); styleInput(pass);
        g.gridy++; login.add(labeled("Usuário",user),g); g.gridy++; login.add(labeled("Senha",pass),g);
        JButton enter=button("Entrar",true,()-> { service.login(user.getText(),new String(pass.getPassword())); pass.setText(""); shell(); });
        g.gridy++; login.add(enter,g); g.gridy++; login.add(label("Acesso exclusivo da equipe da academia",12,false,MUTED),g);
        right.add(login); root.add(brand); root.add(right); setContentPane(root); getRootPane().setDefaultButton(enter); revalidate(); repaint();
    }
    private void shell() throws Exception {
        JPanel root=panel(new BorderLayout(),BG); JPanel side=panel(new BorderLayout(),NAVY); side.setPreferredSize(new Dimension(215,0)); pad(side,30,18,24,18);
        JPanel top=panel(new GridLayout(0,1,0,4),NAVY); top.add(label("pulso.",42,true,new Color(125,220,179))); top.add(label("ACADEMIA MOVIMENTO",10,true,new Color(172,191,191))); pad(top,0,10,24,0); side.add(top,BorderLayout.NORTH);
        JPanel links=panel(new GridLayout(0,1,0,7),NAVY); navigation.clear();
        List<String> pages=new ArrayList<>(List.of("Visão geral","Alunos","Modalidades","Planos","Matrículas","Produtos","Movimentações")); if(service.user().admin()) pages.add("Usuários");
        for(String page:pages) {
            JButton b=new JButton(page); b.setHorizontalAlignment(SwingConstants.LEFT); b.setFont(font(15,false)); b.setFocusPainted(false); b.setForeground(Color.WHITE); b.setBackground(NAVY); pad(b,12,14,12,10); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(e->perform(()->showPage(page))); navigation.put(page,b); links.add(b);
        }
        JPanel linkWrap=panel(new BorderLayout(),NAVY); linkWrap.add(links,BorderLayout.NORTH); side.add(linkWrap,BorderLayout.CENTER);
        JPanel bottom=panel(new GridLayout(0,1,0,8),NAVY); bottom.add(label(service.user().nome(),15,true,Color.WHITE)); bottom.add(label(service.user().admin()?"Administrador":"Atendente",12,false,new Color(172,191,191)));
        bottom.add(button("Sair",false,()-> { service.logout(); showLogin(); })); side.add(bottom,BorderLayout.SOUTH);
        content=panel(new BorderLayout(0,24),BG); pad(content,34,32,30,32); root.add(side,BorderLayout.WEST); root.add(content,BorderLayout.CENTER); setContentPane(root); getRootPane().setDefaultButton(null); showPage("Visão geral");
    }
    private void showPage(String page) throws Exception {
        current=page; content.removeAll(); for(var e:navigation.entrySet()) e.getValue().setBackground(e.getKey().equals(page)?GREEN:NAVY);
        JPanel heading=panel(new BorderLayout(0,8),BG); heading.add(label(page,32,true,TEXT),BorderLayout.NORTH);
        Map<String,String> subtitles=Map.of("Visão geral","O que precisa da atenção da equipe hoje.","Alunos","Cadastro e consulta dos alunos da academia.","Modalidades","Atividades oferecidas aos alunos.","Planos","Valores e duração de cada contratação.","Matrículas","Acompanhe contratos, situações e pagamentos.","Produtos","Confira o saldo e os itens que precisam de reposição.","Movimentações","Entradas e saídas com motivo e responsável.","Usuários","Contas e permissões de acesso da equipe.");
        heading.add(label(subtitles.get(page),15,false,MUTED),BorderLayout.SOUTH); content.add(heading,BorderLayout.NORTH);
        if(page.equals("Visão geral")) dashboard(); else listing(page); content.revalidate(); content.repaint();
    }
    private void dashboard() throws Exception {
        Database db=service.database(); JPanel body=panel(new BorderLayout(0,28),BG);
        JPanel stats=panel(new GridLayout(1,4,16,0),BG);
        stat(stats,"Alunos ativos",db.scalar("SELECT COUNT(*) FROM alunos WHERE ativo=TRUE"),"Cadastros disponíveis");
        stat(stats,"Matrículas ativas",db.scalar("SELECT COUNT(*) FROM matriculas WHERE situacao='ATIVA'"),"Situação do contrato");
        stat(stats,"Pagamentos pendentes",db.scalar("SELECT COUNT(*) FROM matriculas m LEFT JOIN pagamentos p ON p.matricula_id=m.id WHERE p.id IS NULL AND m.situacao<>'CANCELADA'"),"Valor total da contratação");
        stat(stats,"Itens para repor",db.scalar("SELECT COUNT(*) FROM produtos WHERE saldo<=minimo"),"Saldo no mínimo ou abaixo"); body.add(stats,BorderLayout.NORTH);
        JPanel detail=panel(new BorderLayout(0,16),Color.WHITE); pad(detail,24,22,24,22); detail.add(label("Reposição de estoque",21,true,TEXT),BorderLayout.NORTH);
        var alerts=db.query("SELECT nome AS produto,saldo,minimo AS mínimo,unidade FROM produtos WHERE saldo<=minimo ORDER BY nome");
        JTable t=makeTable(alerts,new String[]{"produto","saldo","mínimo","unidade"},new String[]{"Produto","Saldo","Mínimo","Unidade"}); detail.add(scroll(t),BorderLayout.CENTER);
        JPanel foot=panel(new BorderLayout(),Color.WHITE); foot.add(label("Acesse Produtos para consultar ou registrar uma movimentação.",14,false,MUTED),BorderLayout.CENTER); foot.add(button("Ver produtos",true,()->showPage("Produtos")),BorderLayout.EAST); detail.add(foot,BorderLayout.SOUTH);
        body.add(detail,BorderLayout.CENTER); content.add(body,BorderLayout.CENTER); content.add(label("Dados locais. As alterações ficam salvas no computador da academia.",13,false,MUTED),BorderLayout.SOUTH);
    }
    private void stat(JPanel parent,String title,long value,String detail) {
        JPanel p=panel(new BorderLayout(0,10),Color.WHITE); pad(p,22,18,22,18); p.add(label(title,13,true,MUTED),BorderLayout.NORTH); p.add(label(Long.toString(value),38,true,TEXT),BorderLayout.CENTER); p.add(label(detail,11,false,MUTED),BorderLayout.SOUTH); parent.add(p);
    }
    private void listing(String page) throws Exception {
        String sql; String[] keys,headers;
        switch(page) {
            case "Alunos" -> { sql="SELECT * FROM alunos ORDER BY nome"; keys=new String[]{"id","nome","cpf","telefone","email","ativo"}; headers=new String[]{"Código","Nome","CPF","Telefone","E-mail","Ativo"}; }
            case "Modalidades" -> {sql="SELECT * FROM modalidades ORDER BY nome";keys=new String[]{"id","nome","descricao"};headers=new String[]{"Código","Nome","Descrição"};}
            case "Planos" -> {sql="SELECT p.*,m.nome AS modalidade FROM planos p JOIN modalidades m ON m.id=p.modalidade_id ORDER BY p.nome";keys=new String[]{"id","nome","modalidade","valor","meses"};headers=new String[]{"Código","Plano","Modalidade","Valor total","Meses"};}
            case "Matrículas" -> {sql="SELECT m.*,a.nome AS aluno,p.nome AS plano,CASE WHEN pg.id IS NULL THEN 'PENDENTE' ELSE 'PAGO' END AS pagamento FROM matriculas m JOIN alunos a ON a.id=m.aluno_id JOIN planos p ON p.id=m.plano_id LEFT JOIN pagamentos pg ON pg.matricula_id=m.id ORDER BY m.id DESC";keys=new String[]{"id","aluno","plano","inicio","fim","situacao","pagamento","valor"};headers=new String[]{"Código","Aluno","Plano","Início","Fim","Situação","Pagamento","Valor"};}
            case "Produtos" -> {sql="SELECT *,CASE WHEN saldo<=minimo THEN 'REPOR' ELSE 'OK' END AS alerta FROM produtos ORDER BY nome";keys=new String[]{"id","nome","unidade","preco","saldo","minimo","alerta"};headers=new String[]{"Código","Produto","Unidade","Preço","Saldo","Mínimo","Estoque"};}
            case "Movimentações" -> {sql="SELECT m.*,p.nome AS produto,u.nome AS responsavel FROM movimentacoes m JOIN produtos p ON p.id=m.produto_id JOIN usuarios u ON u.id=m.usuario_id ORDER BY m.id DESC";keys=new String[]{"id","data","produto","tipo","quantidade","motivo","responsavel"};headers=new String[]{"Código","Data","Produto","Tipo","Qtd.","Motivo","Responsável"};}
            case "Usuários" -> {sql="SELECT id,nome,login,perfil,ativo FROM usuarios ORDER BY nome";keys=new String[]{"id","nome","login","perfil","ativo"};headers=new String[]{"Código","Nome","Login","Perfil","Ativo"};}
            default -> throw new IllegalArgumentException("Tela desconhecida.");
        }
        rows=service.database().query(sql); table=makeTable(rows,keys,headers);
        TableRowSorter<TableModel> sorter=new TableRowSorter<>(table.getModel()); table.setRowSorter(sorter);
        JPanel body=panel(new BorderLayout(0,18),BG); JPanel toolbar=panel(new BorderLayout(14,0),BG);
        JTextField search=new JTextField(); styleInput(search); search.setToolTipText("Buscar por qualquer informação da lista");
        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e){filter();} public void removeUpdate(javax.swing.event.DocumentEvent e){filter();} public void changedUpdate(javax.swing.event.DocumentEvent e){filter();}
            void filter(){sorter.setRowFilter(RowFilter.regexFilter("(?iu)"+java.util.regex.Pattern.quote(search.getText())));}
        });
        toolbar.add(labeled("Buscar na lista",search),BorderLayout.CENTER);
        JPanel actions=panel(new FlowLayout(FlowLayout.RIGHT,8,18),BG);
        if(page.equals("Matrículas")) {
            actions.add(button("Nova matrícula",true,()->matriculaForm()));
            actions.add(button("Situação",false,()->statusForm()));
            actions.add(button("Pagamento",false,()->paymentForm()));
        } else if(page.equals("Movimentações")) actions.add(button("Registrar movimento",true,()->movementForm(null)));
        else {
            boolean editable=page.equals("Alunos") || service.user().admin();
            if(editable) { actions.add(button("Novo",true,()->editForm(null))); actions.add(button("Editar",false,()->editForm(selected()))); }
            if(page.equals("Produtos")) actions.add(button("Movimentar",true,()->movementForm(selected())));
        }
        toolbar.add(actions,BorderLayout.EAST); body.add(toolbar,BorderLayout.NORTH); body.add(scroll(table),BorderLayout.CENTER);
        JPanel below=panel(new BorderLayout(),BG); below.add(label(rows.size()+" registro(s)  ·  Selecione uma linha para usar as ações",13,false,MUTED),BorderLayout.WEST);
        if(page.equals("Matrículas")) below.add(button("Histórico",false,()->history()),BorderLayout.EAST);
        if(page.equals("Produtos")) below.add(label("REPOR: saldo menor ou igual ao mínimo",13,true,GREEN),BorderLayout.EAST);
        body.add(below,BorderLayout.SOUTH); content.add(body,BorderLayout.CENTER);
    }
    private JTable makeTable(List<Map<String,Object>> data,String[] keys,String[] headers) {
        DefaultTableModel model=new DefaultTableModel(headers,0) { @Override public boolean isCellEditable(int r,int c){return false;} };
        for(var row:data) {Object[] cells=new Object[keys.length]; for(int i=0;i<keys.length;i++) cells[i]=format(row.get(keys[i])); model.addRow(cells);}
        JTable t=new JTable(model); t.setRowHeight(48); t.setFont(font(13,false)); t.setForeground(TEXT); t.setSelectionBackground(new Color(222,241,232)); t.setSelectionForeground(TEXT); t.setGridColor(LINE); t.setShowVerticalLines(false); t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); t.setFillsViewportHeight(true); t.setBackground(Color.WHITE);
        t.getTableHeader().setFont(font(12,true)); t.getTableHeader().setForeground(MUTED); t.getTableHeader().setBackground(new Color(234,240,236)); t.getTableHeader().setPreferredSize(new Dimension(0,42)); t.getTableHeader().setReorderingAllowed(false);
        DefaultTableCellRenderer renderer=new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb,Object v,boolean selected,boolean focus,int r,int c) {
                super.getTableCellRendererComponent(tb,v,selected,focus,r,c); setBorder(new EmptyBorder(0,10,0,10)); setToolTipText(v==null?null:v.toString());
                if(!selected){setBackground(r%2==0?Color.WHITE:new Color(249,251,249));setForeground("REPOR".equals(v)?new Color(160,87,18):TEXT);} return this;
            }
        }; t.setDefaultRenderer(Object.class,renderer);
        for(int i=0;i<headers.length;i++) {t.getColumnModel().getColumn(i).setPreferredWidth(i==0?60:headers[i].equals("Nome")||headers[i].equals("Produto")||headers[i].equals("Plano")?190:120);}
        return t;
    }
    private String format(Object v) {
        if(v==null)return "";
        if(v instanceof BigDecimal b)return currency.format(b);
        if(v instanceof java.sql.Date d)return d.toLocalDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        if(v instanceof java.sql.Timestamp d)return d.toLocalDateTime().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        if(v instanceof Boolean b)return b?"Sim":"Não";
        return v.toString();
    }
    private JScrollPane scroll(JTable t){JScrollPane sc=new JScrollPane(t);sc.setBorder(new LineBorder(LINE));sc.getViewport().setBackground(Color.WHITE);return sc;}
    private Map<String,Object> selected() {
        int row=table.getSelectedRow(); if(row<0)throw new IllegalArgumentException("Selecione um registro na lista.");return rows.get(table.convertRowIndexToModel(row));
    }
    private static void styleInput(JTextField input) {input.setFont(font(15,false));input.setPreferredSize(new Dimension(250,42));input.setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(9,10,9,10)));}
    private static JPanel labeled(String name,JComponent input) {JPanel p=panel(new BorderLayout(0,7),BG);p.add(label(name,13,true,MUTED),BorderLayout.NORTH);p.add(input,BorderLayout.CENTER);return p;}
    private final class Form {
        final JDialog dialog=new JDialog(AcademiaFrame.this,true);
        final JPanel fields=panel(new GridBagLayout(),BG);
        int row=0;
        Form(String title) {
            dialog.setTitle(title); dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            JPanel root=panel(new BorderLayout(0,24),BG);pad(root,26,30,26,30);root.add(label(title,25,true,TEXT),BorderLayout.NORTH);root.add(fields,BorderLayout.CENTER);dialog.setContentPane(root);
        }
        void add(String name,JComponent component) {
            GridBagConstraints g=new GridBagConstraints();g.gridx=0;g.gridy=row++;g.fill=GridBagConstraints.HORIZONTAL;g.weightx=1;g.insets=new Insets(0,0,14,0);fields.add(labeled(name,component),g);
        }
        JTextField text(String name,Object value) {JTextField t=new JTextField(value==null?"":value.toString());styleInput(t);add(name,t);return t;}
        JComboBox<String> options(String name,String[] choices,String selected) {JComboBox<String> c=new JComboBox<>(choices);c.setPreferredSize(new Dimension(300,40));if(selected!=null)c.setSelectedItem(selected);add(name,c);return c;}
        JCheckBox check(String name,boolean selected){JCheckBox c=new JCheckBox("Sim",selected);c.setBackground(BG);add(name,c);return c;}
        JComboBox<Choice> choices(String name,String sql,Object selected) throws Exception {
            List<Map<String,Object>> data=service.database().query(sql);JComboBox<Choice> c=new JComboBox<>();
            for(var r:data){Choice choice=new Choice(AcademiaService.number(r,"id"),r.get("nome").toString());c.addItem(choice);if(selected instanceof Number n && n.longValue()==choice.id())c.setSelectedItem(choice);}
            c.setPreferredSize(new Dimension(360,42));add(name,c);return c;
        }
        void show(Work save) {
            JPanel actions=panel(new FlowLayout(FlowLayout.RIGHT,8,0),BG);actions.add(button("Cancelar",false,()->dialog.dispose()));
            JButton submit=button("Salvar",true,()->{save.run();dialog.dispose();showPage(current);});actions.add(submit);dialog.getContentPane().add(actions,BorderLayout.SOUTH);dialog.getRootPane().setDefaultButton(submit);
            dialog.pack();dialog.setSize(Math.max(500,dialog.getWidth()),dialog.getHeight());dialog.setLocationRelativeTo(AcademiaFrame.this);dialog.setVisible(true);
        }
    }
    private Object val(Map<String,Object> row,String key) {return row==null?null:row.get(key);}
    private static long chosen(JComboBox<Choice> c) {Choice v=(Choice)c.getSelectedItem();if(v==null)throw new IllegalArgumentException("Cadastre os dados necessários antes de continuar.");return v.id();}
    private static BigDecimal decimal(JTextField t) {try{return new BigDecimal(t.getText().trim().replace(",","."));}catch(Exception e){throw new IllegalArgumentException("Informe o valor em reais, por exemplo: 129,90.");}}
    private static int integer(JTextField t) {try{return Integer.parseInt(t.getText().trim());}catch(Exception e){throw new IllegalArgumentException("Informe uma quantidade inteira válida.");}}
    private void editForm(Map<String,Object> r) throws Exception {
        Long id=r==null?null:AcademiaService.number(r,"id");Form f=new Form((id==null?"Novo registro: ":"Editar: ")+current);
        JTextField nome=f.text("Nome",val(r,"nome"));
        switch(current) {
            case "Alunos" -> {
                JTextField cpf=f.text("CPF",val(r,"cpf")),telefone=f.text("Telefone com DDD",val(r,"telefone")),email=f.text("E-mail",val(r,"email"));JCheckBox ativo=f.check("Aluno ativo",r==null||Boolean.TRUE.equals(val(r,"ativo")));
                f.show(()->service.saveAluno(id,nome.getText(),cpf.getText(),telefone.getText(),email.getText(),ativo.isSelected()));
            }
            case "Modalidades" -> {JTextField descricao=f.text("Descrição",val(r,"descricao"));f.show(()->service.saveModalidade(id,nome.getText(),descricao.getText()));}
            case "Planos" -> {
                JComboBox<Choice> m=f.choices("Modalidade","SELECT id,nome FROM modalidades ORDER BY nome",val(r,"modalidade_id"));JTextField valor=f.text("Valor total do plano (R$)",val(r,"valor")),meses=f.text("Duração em meses",r==null?1:val(r,"meses"));
                f.show(()->service.savePlano(id,nome.getText(),chosen(m),decimal(valor),integer(meses)));
            }
            case "Produtos" -> {
                JTextField unidade=f.text("Unidade de medida",r==null?"unidade":val(r,"unidade")),preco=f.text("Preço unitário (R$)",val(r,"preco")),minimo=f.text("Estoque mínimo",r==null?0:val(r,"minimo"));f.add("Saldo inicial",label("Registre uma entrada após salvar o produto.",13,false,MUTED));
                f.show(()->service.saveProduto(id,nome.getText(),unidade.getText(),decimal(preco),integer(minimo)));
            }
            case "Usuários" -> {
                JTextField login=f.text("Login",val(r,"login"));JPasswordField senha=new JPasswordField();styleInput(senha);f.add(id==null?"Senha (mínimo de 8 caracteres)":"Nova senha (em branco mantém a atual)",senha);
                JComboBox<String> perfil=f.options("Perfil",new String[]{"ATENDENTE","ADMIN"},r==null?"ATENDENTE":val(r,"perfil").toString());JCheckBox ativo=f.check("Conta ativa",r==null||Boolean.TRUE.equals(val(r,"ativo")));
                f.show(()->service.saveUsuario(id,nome.getText(),login.getText(),new String(senha.getPassword()),perfil.getSelectedItem().toString(),ativo.isSelected()));
            }
        }
    }
    private void matriculaForm() throws Exception {
        Form f=new Form("Nova matrícula");JComboBox<Choice> aluno=f.choices("Aluno ativo","SELECT id,nome FROM alunos WHERE ativo=TRUE ORDER BY nome",null);
        JComboBox<Choice> plano=f.choices("Plano","SELECT id,CONCAT(nome,' - R$ ',valor) AS nome FROM planos ORDER BY nome",null);
        JTextField inicio=f.text("Início (dd/mm/aaaa)",LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
        f.add("Contratação",label("O pagamento corresponde ao valor total do plano.",13,false,MUTED));
        f.show(()-> {LocalDate data;try{data=LocalDate.parse(inicio.getText(),DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(java.time.format.ResolverStyle.STRICT));}catch(Exception e){throw new IllegalArgumentException("Informe uma data válida no formato dd/mm/aaaa.");} service.matricular(chosen(aluno),chosen(plano),data);});
    }
    private void statusForm() {
        var r=selected();Form f=new Form("Situação da matrícula #"+r.get("id"));JComboBox<String> status=f.options("Nova situação",new String[]{"ATIVA","TRANCADA","CANCELADA"},r.get("situacao").toString());JTextField motivo=f.text("Motivo da alteração",null);
        f.show(()->service.situacao(AcademiaService.number(r,"id"),status.getSelectedItem().toString(),motivo.getText()));
    }
    private void paymentForm() {
        var r=selected();Form f=new Form("Registrar pagamento");f.add("Aluno",label(r.get("aluno").toString(),16,true,TEXT));f.add("Valor da contratação",label(format(r.get("valor")),24,true,GREEN));JComboBox<String> forma=f.options("Forma de pagamento",new String[]{"PIX","DINHEIRO","CARTAO"},"PIX");
        f.show(()->service.pagar(AcademiaService.number(r,"id"),forma.getSelectedItem().toString()));
    }
    private void movementForm(Map<String,Object> r) throws Exception {
        Form f=new Form("Registrar movimentação");JComboBox<Choice> produto=f.choices("Produto e saldo atual","SELECT id,CONCAT(nome,' (saldo: ',saldo,')') AS nome FROM produtos ORDER BY nome",val(r,"id"));
        JComboBox<String> tipo=f.options("Tipo",new String[]{"ENTRADA","SAIDA"},"ENTRADA");JTextField qtd=f.text("Quantidade inteira",1),motivo=f.text("Motivo",null);
        f.show(()->service.movimentar(chosen(produto),tipo.getSelectedItem().toString(),integer(qtd),motivo.getText()));
    }
    private void history() throws Exception {
        var r=selected();long id=AcademiaService.number(r,"id");var hist=service.database().query("SELECT h.data,h.situacao,h.motivo,u.nome AS responsavel FROM historico_matriculas h JOIN usuarios u ON u.id=h.usuario_id WHERE h.matricula_id=? ORDER BY h.id",id);
        JDialog d=new JDialog(this,"Histórico da matrícula #"+id,true);JPanel p=panel(new BorderLayout(0,14),BG);pad(p,22,22,22,22);p.add(label("Alterações de situação",24,true,TEXT),BorderLayout.NORTH);p.add(scroll(makeTable(hist,new String[]{"data","situacao","motivo","responsavel"},new String[]{"Data","Situação","Motivo","Responsável"})),BorderLayout.CENTER);d.setContentPane(p);d.setSize(900,430);d.setLocationRelativeTo(this);d.setVisible(true);
    }
    /** Exporta a mesma interface do aplicativo com dados descartáveis de demonstração. */
    public void captureScreens() throws Exception {
        Files.createDirectories(Path.of("assets/telas")); setVisible(true); capture("01-login");
        service.login("admin","Admin@123");shell();
        String[] pages={"Visão geral","Alunos","Modalidades","Planos","Matrículas","Produtos","Movimentações","Usuários"};
        for(int i=0;i<pages.length;i++){showPage(pages[i]);capture(String.format("%02d-",i+2)+new String[]{"inicio","alunos","modalidades","planos","matriculas","produtos","movimentacoes","usuarios"}[i]);}
    }
    private void capture(String name) throws Exception {
        validate();getContentPane().doLayout();validate();Toolkit.getDefaultToolkit().sync();
        BufferedImage img=new BufferedImage(getContentPane().getWidth(),getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=img.createGraphics();getContentPane().printAll(g);g.dispose();ImageIO.write(img,"png",Path.of("assets/telas/"+name+".png").toFile());
    }
}
